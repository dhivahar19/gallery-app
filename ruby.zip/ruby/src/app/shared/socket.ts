function twoDigits(n: number): string {
  if (n >= 10) {
    return n.toString();
  }

  return ('0' + n.toString()).slice(-2);
}

const wsUri = 'wss://public-api.smarttra.de/up?token=TY4D2Pkfl4UVmXCH';
const now_day = new Date();

const nowYearAndMonth = now_day.getFullYear() + twoDigits(now_day.getMonth() + 1);
const today = nowYearAndMonth + twoDigits(now_day.getDate());
const day_begin = today + '080000';
const day_end = today + '00';

const y_day = new Date(now_day);
y_day.setDate(now_day.getDate() - 1);

const isMonday = now_day.toString().includes('Mon');
const prev_day = !isMonday ? today : nowYearAndMonth + twoDigits(now_day.getDate() - 2);

const day_middle_yest = nowYearAndMonth + twoDigits(now_day.getDate() - 1) + '235000';

const day_end_yest = nowYearAndMonth + twoDigits(now_day.getDate() - 1) + '235959';

const day_middle_fri = nowYearAndMonth + twoDigits(now_day.getDate() - 3) + '235000';
const day_end_fri = nowYearAndMonth + twoDigits(now_day.getDate() - 3) + '235959';

const lastyear = 2016 + twoDigits(y_day.getMonth() + 1) + twoDigits(y_day.getDate());

let _sendMessage = (_message?: any): any => {};

let _sendMessageIntraday = (_message?: any): any => {};

let _sendMessageCurr = (_message?: any): any => {};

const dataIntraDay = {};

let done = 0;

/**
 * Detect if we are on a Mobile navigator
 */
function detectMobile() {
  const mobileRegex = /Android|webOS|iPhone|iPad|iPod|BlackBerry|Windows Phone/i;
  return mobileRegex.test(navigator.userAgent);
}

const ratio = window.devicePixelRatio || 1;
const w = screen.width * ratio;
const h = screen.height * ratio;

function init() {
  initTestWebSocket();

  if (w < 780 && detectMobile()) {
    CurrencyWebSocket();
  }
}

let testWebsocket: WebSocket;
let websocketIntraday: WebSocket;
let websocketCurr: WebSocket;

function initTestWebSocket() {
  testWebsocket = new WebSocket(wsUri);

  testWebsocket.onopen = onOpen;
  testWebsocket.onclose = onClose;
  testWebsocket.onmessage = onMessage;
  testWebsocket.onerror = onError;
}

function IntradayWebSocket() {
  websocketIntraday = new WebSocket(wsUri);

  websocketIntraday.onopen = onOpenIntraday;
  websocketIntraday.onclose = onClose;
  websocketIntraday.onmessage = onMessageIntraday;
  websocketIntraday.onerror = onError;
}

function CurrencyWebSocket() {
  websocketCurr = new WebSocket(wsUri);

  websocketCurr.onopen = onOpenCurr;
  websocketCurr.onclose = onClose;
  websocketCurr.onmessage = onMessageCurr;
  websocketCurr.onerror = onError;
}

function onOpen() {
  writeToScreen('CONNECTED');

  doSend('option udl_ccy 0\n');
  doSend(
    'sub US6311011026 FR0003500008 DE0008469008 US2605661048 ES0SI0000005 ' +
      'GB0001383545 EU0009658145 DE0007100000 CH0001693230 JP9010C00002 CH0009980894' +
      ' DE0008467416 DE0007203275 DE0009653386 US78378X1072 NL0000000107 AT0000999982 DE000ZAL1111' +
      ' HK0000004330 HK0000004322 IT0003465736 SE0000337842 FI0008900212 US0378331005\n'
  );
  doSend('sub FI0008900212 XC0009665545 XC0009665529\n');

  doSend('sub_fx EUR-USD EUR-GBP EUR-CHF EUR-BTC EUR-JPY XAU-USD XAG-USD\n');

  doSend('historical US6311011026 ' + prev_day + ' ' + today + '\n');
  doSend('historical FR0003500008 ' + prev_day + ' ' + today + '\n');
  doSend('historical DE0008469008 ' + prev_day + ' ' + today + '\n');
  doSend('historical US2605661048 ' + prev_day + ' ' + today + '\n');
  doSend('historical ES0SI0000005 ' + prev_day + ' ' + today + '\n');
  doSend('historical GB0001383545 ' + prev_day + ' ' + today + '\n');

  doSend('historical EU0009658145 ' + prev_day + ' ' + today + '\n');
  doSend('historical CH0001693230 ' + prev_day + ' ' + today + '\n');
  doSend('historical DE0007100000 ' + prev_day + ' ' + today + '\n');
  doSend('historical JP9010C00002 ' + prev_day + ' ' + today + '\n');
  doSend('historical CH0009980894 ' + prev_day + ' ' + today + '\n');

  doSend('historical DE0008467416 ' + prev_day + ' ' + today + '\n');
  doSend('historical DE0007203275 ' + prev_day + ' ' + today + '\n');
  doSend('historical DE0009653386 ' + prev_day + ' ' + today + '\n');
  doSend('historical US78378X1072 ' + prev_day + ' ' + today + '\n');
  doSend('historical NL0000000107 ' + prev_day + ' ' + today + '\n');

  doSend('historical AT0000999982 ' + prev_day + ' ' + today + '\n');
  doSend('historical DE000ZAL1111 ' + prev_day + ' ' + today + '\n');
  doSend('historical HK0000004330 ' + prev_day + ' ' + today + '\n');
  doSend('historical HK0000004322 ' + prev_day + ' ' + today + '\n');
  doSend('historical IT0003465736 ' + prev_day + ' ' + today + '\n');

  doSend('historical SE0000337842 ' + prev_day + ' ' + today + '\n');
  doSend('historical FI0008900212 ' + prev_day + ' ' + today + '\n');
  doSend('historical US0378331005 ' + prev_day + ' ' + today + '\n');
  // doSend("historical EUR-USD " + prev_day + " " + today + "\n");
  // doSend("historical EUR-GBP " + prev_day + " " + today + "\n");
  // doSend("historical EUR-CHF " + prev_day + " " + today + "\n");
  // doSend("historical EUR-BTC " + prev_day + " " + today + "\n");
  // doSend("historical EUR-JPY " + prev_day + " " + today + "\n");
  // doSend("historical XAU-USD " + prev_day + " " + today + "\n");
  //  doSend("historical XAG-USD " + prev_day + " " + today + "\n");
}

function onOpenIntraday() {
  writeToScreenIntraday('CONNECTED');

  doSendIntraday('option udl_ccy 0\n');

  doSendIntraday('intraday US6311011026 ' + day_begin + ' ' + day_end + '\n');
  doSendIntraday('intraday FR0003500008 ' + day_begin + ' ' + day_end + '\n');
  doSendIntraday('intraday DE0008469008 ' + day_begin + ' ' + day_end + '\n');
  doSendIntraday('intraday US2605661048 ' + day_begin + ' ' + day_end + '\n');
  doSendIntraday('intraday ES0SI0000005 ' + day_begin + ' ' + day_end + '\n');
  doSendIntraday('intraday GB0001383545 ' + day_begin + ' ' + day_end + '\n');

  doSendIntraday('intraday EU0009658145 ' + day_begin + ' ' + day_end + '\n');
  doSendIntraday('intraday CH0001693230 ' + day_begin + ' ' + day_end + '\n');
  doSendIntraday('intraday DE0007100000 ' + day_begin + ' ' + day_end + '\n');
  doSendIntraday('intraday JP9010C00002 ' + day_begin + ' ' + day_end + '\n');
  doSendIntraday('intraday CH0009980894 ' + day_begin + ' ' + day_end + '\n');

  doSendIntraday('intraday DE0008467416 ' + day_begin + ' ' + day_end + '\n');
  doSendIntraday('intraday DE0007203275 ' + day_begin + ' ' + day_end + '\n');
  doSendIntraday('intraday DE0009653386 ' + day_begin + ' ' + day_end + '\n');
  doSendIntraday('intraday US78378X1072 ' + day_begin + ' ' + day_end + '\n');
  doSendIntraday('intraday NL0000000107 ' + day_begin + ' ' + day_end + '\n');

  doSendIntraday('intraday AT0000999982 ' + day_begin + ' ' + day_end + '\n');
  doSendIntraday('intraday DE000ZAL1111 ' + day_begin + ' ' + day_end + '\n');
  doSendIntraday('intraday HK0000004330 ' + day_begin + ' ' + day_end + '\n');
  doSendIntraday('intraday HK0000004322 ' + day_begin + ' ' + day_end + '\n');
  doSendIntraday('intraday IT0003465736 ' + day_begin + ' ' + day_end + '\n');

  doSendIntraday('intraday SE0000337842 ' + day_begin + ' ' + day_end + '\n');
  doSendIntraday('intraday FI0008900212 ' + day_begin + ' ' + day_end + '\n');
  doSendIntraday('intraday US0378331005 ' + day_begin + ' ' + day_end + '\n');
  doSendIntraday('intraday_fx EUR-USD ' + day_begin + ' ' + day_end + '\n');
  doSendIntraday('intraday_fx EUR-GBP ' + day_begin + ' ' + day_end + '\n');
  doSendIntraday('intraday_fx EUR-CHF ' + day_begin + ' ' + day_end + '\n');
  doSendIntraday('intraday_fx EUR-BTC ' + day_begin + ' ' + day_end + '\n');
  doSendIntraday('intraday_fx EUR-JPY ' + day_begin + ' ' + day_end + '\n');
  doSendIntraday('intraday_fx XAU-USD ' + day_begin + ' ' + day_end + '\n');
  doSendIntraday('intraday_fx XAG-USD ' + day_begin + ' ' + day_end + '\n');
}

function onOpenCurr() {
  writeToScreenCurr('CONNECTED');

  doSendCurr('option udl_ccy 0\n');

  if (now_day.toString().includes('Mon')) {
    doSendCurr('intraday_fx EUR-USD ' + day_middle_fri + ' ' + day_end_fri + '\n');
    doSendCurr('intraday_fx EUR-GBP ' + day_middle_fri + ' ' + day_end_fri + '\n');
    doSendCurr('intraday_fx EUR-CHF ' + day_middle_fri + ' ' + day_end_fri + '\n');
    doSendCurr('intraday_fx EUR-JPY ' + day_middle_fri + ' ' + day_end_fri + '\n');
    doSendCurr('intraday_fx XAU-USD ' + day_middle_fri + ' ' + day_end_fri + '\n');
    doSendCurr('intraday_fx XAG-USD ' + day_middle_fri + ' ' + day_end_fri + '\n');
  } else {
    doSendCurr('intraday_fx EUR-USD ' + day_middle_yest + ' ' + day_end_yest + '\n');
    doSendCurr('intraday_fx EUR-GBP ' + day_middle_yest + ' ' + day_end_yest + '\n');
    doSendCurr('intraday_fx EUR-CHF ' + day_middle_yest + ' ' + day_end_yest + '\n');
    doSendCurr('intraday_fx EUR-JPY ' + day_middle_yest + ' ' + day_end_yest + '\n');
    doSendCurr('intraday_fx XAU-USD ' + day_middle_yest + ' ' + day_end_yest + '\n');
    doSendCurr('intraday_fx XAG-USD ' + day_middle_yest + ' ' + day_end_yest + '\n');
  }
}

function onClose() {
  writeToScreen('DISCONNECTED');
}

function parseResponseIntraday(str) {
  const response: any = {};
  str = str.trim(str);

  if (str.match(/done/)) {
    console.log(str);
    done++;
    return { done: true };
  }

  let match = /^(?:([a-z0-9]+)@)?Error(?:\s\d+)?:\s(.*)$/i.exec(str);

  if (!str || str === 'pong') {
    return null;
  }

  if (match) {
    response.id = match[1];
    response.error = match[2];
    return response;
  }

  match = /^([a-z0-9]+)@(.*)$/i.exec(str);

  if (!match) {
    match = /^([A-Z]+-[A-Z]+)@(.*)$/i.exec(str);
    if (!match) {
      console.warn('Invalid response: ' + str);
      return null;
    }
  }

  response.id = match[1];
  const dataLine = match[2];
  response.data = {};

  const regex = /([a-z]+):([^:;]+)(?:;|$)/gi;
  let time: number;
  let bid: number;
  let ask: number;

  while ((match = regex.exec(dataLine))) {
    const key = match[1];
    const value = match[2];

    if (key === 'p') {
      // key = 'price';
      bid = parseFloat(value);
      ask = parseFloat(value);
    } else if (key === 't') {
      // key = 'time';
      time = parseDateIntraday(value);
    }

    response.data['price'] = (bid + ask) * 0.5;
    response.data['time'] = time;
  }

  return response;
}

function parseResponse(str) {
  const response: any = {};
  str = str.trim(str);

  if (str.match(/done/)) {
    return;
  }

  let match = /^(?:([a-z0-9]+)@)?Error(?:\s\d+)?:\s(.*)$/i.exec(str);

  if (!str || str === 'pong') {
    return null;
  }

  if (match) {
    response.id = match[1];
    response.error = match[2];
    return response;
  }

  match = /^([a-z0-9]+)@(.*)$/i.exec(str);

  if (!match) {
    match = /^([A-Z]+-[A-Z]+)@(.*)$/i.exec(str);
    if (!match) {
      console.warn('Invalid response: ' + str);
      return null;
    }
  }

  response.id = match[1];
  const dataLine = match[2];
  response.data = {};

  const regex = /([a-z]+):([^:;]+)(?:;|$)/gi;
  let time: string;
  let currency: string;
  let bid: number;
  let ask: number;
  let dateValue;
  let highValue;
  let lowValue;
  let openValue;
  let closeValue;

  while ((match = regex.exec(dataLine))) {
    const key = match[1];
    const value = match[2];

    switch (key) {
      case 'p':
        // key = 'price';
        bid = parseFloat(value);
        ask = parseFloat(value);
        break;
      case 't':
        // key = 'time';
        time = parseDate(value);
        break;
      case 'c':
        // key = 'priceCurrency';
        currency = value;
        closeValue = value;
        break;
      case 'b':
        bid = parseFloat(value);
        break;
      case 'a':
        ask = parseFloat(value);
        break;
      case 'h':
        highValue = value;
        break;
      case 'l':
        lowValue = value;
        break;
      case 'o':
        openValue = value;
        break;
      case 'd':
        dateValue = value;
        break;
      default:
        break;
    }

    response.data.price = (bid + ask) * 0.5;
    response.data.time = time;
    response.data.priceCurrency = currency;

    response.data.highValue = highValue;
    response.data.lowValue = lowValue;
    response.data.openValue = openValue;
    response.data.closeValue = closeValue;
    response.data.dateValue = dateValue;
  }

  return response;
}

function parseDate(dateStr) {
  const mask = /^(\d\d\d\d)(\d\d)(\d\d)(\d\d)(\d\d)(\d\d)$/.exec(dateStr);
  if (mask) {
    return mask[1] + '-' + mask[2] + '-' + mask[3] + ' ' + mask[4] + ':' + mask[5] + ':' + mask[6];
  }
  return null;
}

function parseDateIntraday(dateStr) {
  const mask: any[] = /^(\d\d\d\d)(\d\d)(\d\d)(\d\d)(\d\d)(\d\d)$/.exec(dateStr);
  const timeMask: any[] = /^(\d\d)(\d\d)(\d\d)$/.exec(dateStr);

  if (mask) {
    const month = +mask[2] - 1;
    return Date.UTC(mask[1], month, mask[3], mask[4], mask[5], mask[6]);
  }

  if (timeMask) {
    return Date.UTC(
      now_day.getFullYear(),
      now_day.getMonth(),
      now_day.getDate(),
      timeMask[1],
      timeMask[2],
      timeMask[3]
    );
  }
  return null;
}

function onMessage(evt: any) {
  const response = parseResponse(evt.data);
  writeToScreen(response);
}

function onMessageIntraday(evt: any) {
  const response = parseResponseIntraday(evt.data);
  writeToScreenIntraday(response);
}

function onMessageCurr(evt: any) {
  const response = parseResponseIntraday(evt.data);
  writeToScreenCurr(response);
}

function onError(evt: any) {
  writeToScreen(evt.data);
}

function doSend(message: any) {
  writeToScreen('SENT: ' + message);
  testWebsocket.send(message);
}

function doSendIntraday(message: any) {
  writeToScreenIntraday('SENT: ' + message);
  websocketIntraday.send(message);
}

function doSendCurr(message: any) {
  writeToScreenCurr('SENT: ' + message);
  websocketCurr.send(message);
}

// Перенаправление на вывод через ангулар в real-time-indications.component.ts
function writeToScreen(message: any) {
  _sendMessage(message);
}

function writeToScreenIntraday(message: any) {
  // if (message.done) {
  if (done === 31) {
    _sendMessageIntraday(dataIntraDay);
    hideElements('.preloader-chart');
  } else {
    if (dataIntraDay[message.id]) {
      dataIntraDay[message.id].push(message);
    } else {
      if (message.id) {
        dataIntraDay[message.id] = [message];
      }
    }
  }
  // }
}

function writeToScreenCurr(message: any) {
  // if (message.done) {
  if (done === 6) {
    _sendMessageCurr(dataIntraDay);
    hideElements('.preloader');
  } else {
    if (dataIntraDay[message.id]) {
      dataIntraDay[message.id].push(message);
    } else {
      if (message.id) {
        dataIntraDay[message.id] = [message];
      }
    }
  }
  // }
}

const win: Window | any = window;

win.onSendMessage = (callback: typeof _sendMessage) => {
  _sendMessage = callback;
};

win.onSendMessageIntraday = (callback: typeof _sendMessageIntraday) => {
  _sendMessageIntraday = callback;
};

win.onSendMessageCurr = (callback: typeof _sendMessageCurr) => {
  _sendMessageCurr = callback;
};

win.initSocket = init;

function hideElements(selector: string) {
  const nodes = document.querySelectorAll<HTMLElement>(selector);
  nodes.forEach((node) => (node.style.display = 'none'));
}

// window.addEventListener("load", init, false);
