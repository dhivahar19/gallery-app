import { Component } from '@angular/core';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.css'],
})
export class NavigationComponent {
  constructor() {}
  public up(): void {
    window.scrollTo(0, 0);
  }
}
