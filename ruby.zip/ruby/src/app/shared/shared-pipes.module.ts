import { NgModule } from '@angular/core';

import { OrderbyPipe } from './orderby.pipe';
import { FilterPipe } from './category.pipe';

@NgModule({
  declarations: [FilterPipe, OrderbyPipe],
  exports: [FilterPipe, OrderbyPipe],
})
export class SharedPipesModule {}
