import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'category',
  pure: true,
})
export class FilterPipe implements PipeTransform {
  static readonly indexes = [
    'NASDAQ',
    'CAC40',
    'DAX',
    'IBEX',
    'ESTX50',
    'FTSE100',
    'DOW Jones',
    'NIKKEI',
    'SMI',
    'MDAX',
    'TECDAX',
    'SDAX',
    'SP500',
    'AEX',
    'ATX',
    'ZALANDO',
    'HSCI',
    'HANG',
    'FTSEMIB',
    'OMXS30',
    'OMXH25',
    'USD',
    'GBP',
    'JPY',
    'GOLD',
    'SILVER',
    'APPLE',
    'CHF',
    'BTC',
  ];

  transform(categories: any, searchText: any): any {
    if (searchText === undefined) {
      return categories;
    }

    const isAKnowSearchTerm = FilterPipe.indexes.includes(searchText);
    this.handleElementsVisibility(searchText, isAKnowSearchTerm);

    return categories.filter((category) => {
      if (isAKnowSearchTerm) {
        return category.name.toLowerCase().includes(searchText.toLowerCase());
      }

      return category.id.toLowerCase().includes(searchText.toLowerCase());
    });
  }

  private handleElementsVisibility(searchText: string, isAKnowSearchTerm: boolean) {
    if (isAKnowSearchTerm) {
      this.handleElementsVisibilityForAKnowSearchText(searchText);
    } else {
      this.handleElementsVisibilityForAUnknowSearchText(searchText);
    }
  }

  private handleElementsVisibilityForAUnknowSearchText(searchText: string) {
    const { fx, ind, com } = this.getElements();

    if (searchText === '') {
      fx.style.display = 'block';
      ind.style.display = 'block';
      com.style.display = 'block';
    } else if (
      searchText === 'CHF' ||
      searchText === 'BTC' ||
      searchText === 'JPY' ||
      searchText === 'GBP' ||
      searchText === 'USD'
    ) {
      fx.style.display = 'block';
      ind.style.display = 'none';
      com.style.display = 'none';
    } else if (searchText === 'GOLD' || searchText === 'SILVER') {
      fx.style.display = 'none';
      ind.style.display = 'none';
      com.style.display = 'block';
    } else {
      fx.style.display = 'none';
      ind.style.display = 'block';
      com.style.display = 'none';
    }
  }

  private handleElementsVisibilityForAKnowSearchText(searchText: string) {
    const { fx, ind, com } = this.getElements();

    if (searchText === '') {
      fx.style.display = 'block';
      ind.style.display = 'block';
      com.style.display = 'block';
    } else if (
      searchText === 'EUR-CHF' ||
      searchText === 'EUR-BTC' ||
      searchText === 'EUR-JPY' ||
      searchText === 'EUR-GBP' ||
      searchText === 'EUR-USD'
    ) {
      fx.style.display = 'block';
      ind.style.display = 'none';
      com.style.display = 'none';
    } else if (searchText === 'EUR-XAU' || searchText === 'EUR-XAG') {
      fx.style.display = 'none';
      ind.style.display = 'none';
      com.style.display = 'block';
    } else {
      fx.style.display = 'none';
      ind.style.display = 'block';
      com.style.display = 'none';
    }
  }

  getElements() {
    return {
      fx: document.getElementById('fx'),
      com: document.getElementById('com'),
      ind: document.getElementById('ind'),
    };
  }
}
