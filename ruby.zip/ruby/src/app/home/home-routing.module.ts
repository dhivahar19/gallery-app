import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RealTimeIndicationsComponent } from './real-time-indications/real-time-indications.component';

const routes: Routes = [{
  path: '',
  component: RealTimeIndicationsComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomeRoutingModule { }
