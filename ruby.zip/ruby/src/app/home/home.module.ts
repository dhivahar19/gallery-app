import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DragDropModule } from '@angular/cdk/drag-drop';


import { HomeRoutingModule } from './home-routing.module';
import { RealTimeIndicationsComponent } from './real-time-indications/real-time-indications.component';
import { SharedPipesModule } from '../shared/shared-pipes.module';

import { ChartModule } from 'angular2-highcharts';
import { HighchartsStatic } from 'angular2-highcharts/dist/HighchartsService';

declare function require(moduleName: string): any;
export function highchartsFactory() {
  const hc = require('highcharts/highstock');
  const dd = require('highcharts/modules/exporting');
  dd(hc);
  return hc;
}

@NgModule({
  declarations: [RealTimeIndicationsComponent],
  imports: [
    CommonModule,
    FormsModule,
    DragDropModule,
    HomeRoutingModule,
    SharedPipesModule,
    ChartModule
  ],
  providers: [
    {
      provide: HighchartsStatic,
      useFactory: highchartsFactory,
    },
  ]
})
export class HomeModule { }
