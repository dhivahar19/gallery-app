import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RealTimeIndicationsComponent } from './real-time-indications.component';

describe('RealTimeIndicationsComponent', () => {
  let component: RealTimeIndicationsComponent;
  let fixture: ComponentFixture<RealTimeIndicationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RealTimeIndicationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RealTimeIndicationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
