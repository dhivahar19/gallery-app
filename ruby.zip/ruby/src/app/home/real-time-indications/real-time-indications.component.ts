import { Component, HostListener, NgZone, OnInit } from '@angular/core';

import {CdkDragDrop, moveItemInArray} from '@angular/cdk/drag-drop';

import '../../shared/socket';

declare var onSendMessage: any;
declare var initSocket: any;
declare var onSendMessageIntraday: any;
declare var onSendMessageCurr: any;

@Component({
  selector: 'app-real-time-indications',
  templateUrl: './real-time-indications.component.html',
  styleUrls: ['./real-time-indications.component.css'],
})
export class RealTimeIndicationsComponent implements OnInit {
  searchText;

  wsUri = 'wss://public-api.SMARTTRA.DE/up?token=TY4D2Pkfl4UVmXCH';

  name = '';
  exampleId = 'US6311011026';
  exampleName = 'IBEX';

  // Variables for table sort
  isDesc = false;
  column = 'indication';
  direction: number;
  // Variables for outputting data / charts
  public table_info: Array<Object>;
  public table_info_fx: Array<Object>;
  public table_info_com: Array<Object>;
  chartList: Object = {};
  chartListBar: Object = {};
  chartBar: any;
  chart: any;
  chartOpen: any;
  options: Object;
  options3: Object;
  info;

  // An array with indexes and names
  indexes = [
    { id: 'US6311011026', name: 'smarttra.de estimation for NASDAQ' },
    { id: 'FR0003500008', name: 'smarttra.de estimation for CAC40' },
    { id: 'DE0008469008', name: 'smarttra.de estimation for DAX' },
    { id: 'ES0SI0000005', name: 'smarttra.de estimation for IBEX' },
    { id: 'EU0009658145', name: 'smarttra.de estimation for ESTX50' },
    { id: 'GB0001383545', name: 'smarttra.de estimation for FTSE100' },
    { id: 'US2605661048', name: 'smarttra.de estimation for DOW Jones' },
    { id: 'JP9010C00002', name: 'smarttra.de estimation for NIKKEI' },
    { id: 'CH0009980894', name: 'smarttra.de estimation for SMI' },
    { id: 'DE0008467416', name: 'smarttra.de estimation for MDAX' },
    { id: 'DE0007203275', name: 'smarttra.de estimation for TECDAX' },
    { id: 'DE0009653386', name: 'smarttra.de estimation for SDAX' },
    { id: 'US78378X1072', name: 'smarttra.de estimation for SP500' },
    { id: 'NL0000000107', name: 'smarttra.de estimation for AEX' },
    { id: 'AT0000999982', name: 'smarttra.de estimation for ATX' },
    { id: 'DE000ZAL1111', name: 'smarttra.de estimation for ZALANDO' },
    { id: 'HK0000004330', name: 'smarttra.de estimation for HSCI' },
    { id: 'HK0000004322', name: 'smarttra.de estimation for HANG' },
    { id: 'IT0003465736', name: 'smarttra.de estimation for FTSEMIB' },
    { id: 'SE0000337842', name: 'smarttra.de estimation for OMXS30' },
    { id: 'FI0008900212', name: 'smarttra.de estimation for OMXH25' },
    { id: 'DE0007100000', name: 'smarttra.de estimation for DAIMLER' },
    { id: 'US0378331005', name: 'smarttra.de estimation for APPLE' },
    { id: 'EUR-USD', name: 'USD' },
    { id: 'EUR-GBP', name: 'GBP' },
    { id: 'EUR-JPY', name: 'JPY' },
    { id: 'XAU-USD', name: 'GOLD' },
    { id: 'XAG-USD', name: 'SILVER' },
    { id: 'EUR-CHF', name: 'CHF' },
    { id: 'EUR-BTC', name: 'BTC-EUR' },
    { id: 'XC0009655157', name: 'XC0009655157' },
    { id: 'XC0009665545', name: 'XC0009665545' },
    { id: 'XC0009665529', name: 'XC0009665529' },
    { id: 'XC0009653103', name: 'XC0009653103' },
  ];

  fx_indexes = ['USD', 'GBP', 'JPY', 'BTC-EUR', 'CHF'];
  com_indexes = ['GOLD', 'SILVER', 'XC0009655157', 'XC0009665545', 'XC0009665529', 'XC0009653103'];

  fx_ids = ['EUR-USD', 'EUR-GBP', 'EUR-JPY', 'EUR-BTC', 'EUR-CHF'];

  data: any;

  // Variables for date formation
  now_day = new Date();
  day_begin =
    this.now_day.getFullYear() +
    ('0' + (this.now_day.getMonth() + 1)).slice(-2) +
    ('0' + this.now_day.getDate()).slice(-2) +
    '080000';
  day_end =
    this.now_day.getFullYear() +
    ('0' + (this.now_day.getMonth() + 1)).slice(-2) +
    ('0' + this.now_day.getDate()).slice(-2) +
    this.now_day.getHours() +
    '' +
    this.now_day.getMinutes() +
    this.now_day.getSeconds();

  day_begin_yest =
    this.now_day.getFullYear() +
    ('0' + (this.now_day.getMonth() + 1)).slice(-2) +
    ('0' + (this.now_day.getDate() - 1)).slice(-2) +
    '080000';
  day_middle_yest =
    this.now_day.getFullYear() +
    ('0' + (this.now_day.getMonth() + 1)).slice(-2) +
    ('0' + (this.now_day.getDate() - 1)).slice(-2) +
    '235000';
  day_end_yest =
    this.now_day.getFullYear() +
    ('0' + (this.now_day.getMonth() + 1)).slice(-2) +
    ('0' + (this.now_day.getDate() - 1)).slice(-2) +
    '235959';

  day_begin_fri =
    this.now_day.getFullYear() +
    ('0' + (this.now_day.getMonth() + 1)).slice(-2) +
    ('0' + (this.now_day.getDate() - 3)).slice(-2) +
    '080000';
  day_middle_fri =
    this.now_day.getFullYear() +
    ('0' + (this.now_day.getMonth() + 1)).slice(-2) +
    ('0' + (this.now_day.getDate() - 3)).slice(-2) +
    '235000';
  day_end_fri =
    this.now_day.getFullYear() +
    ('0' + (this.now_day.getMonth() + 1)).slice(-2) +
    ('0' + (this.now_day.getDate() - 3)).slice(-2) +
    '235959';

  today =
    this.now_day.getFullYear() +
    ('0' + (this.now_day.getMonth() + 1)).slice(-2) +
    ('0' + this.now_day.getDate()).slice(-2);
  week_ago =
    this.now_day.getFullYear() +
    ('0' + (this.now_day.getMonth() + 1)).slice(-2) +
    ('0' + (this.now_day.getDate() - 7)).slice(-2);
  two_weeks_ago = this.now_day.getFullYear() +
    ('0' + (this.now_day.getMonth() + 1)).slice(-2) +
    ('0' + (this.now_day.getDate() - 14)).slice(-2);
  month_ago =
    this.now_day.getFullYear() + ('0' + this.now_day.getMonth()).slice(-2) + ('0' + this.now_day.getDate()).slice(-2);
  three_months_ago = this.getPrevMonthsDateFromToday(3).split('-').join('');
  six_months_ago = this.getPrevMonthsDateFromToday(6).split('-').join('');
  year_ago =
    this.now_day.getFullYear() -
    1 +
    ('0' + this.now_day.getMonth()).slice(-2) +
    ('0' + this.now_day.getDate()).slice(-2);
  five_years_ago =
    this.now_day.getFullYear() -
    5 +
    ('0' + this.now_day.getMonth()).slice(-2) +
    ('0' + this.now_day.getDate()).slice(-2);
  max_time_ago = '19700101';

  week = this.GetDayCount(
    this.now_day.getFullYear() +
      '-' +
      ('0' + (this.now_day.getMonth() + 1)).slice(-2) +
      '-' +
      ('0' + (this.now_day.getDate() - 7)).slice(-2)
  );
  month = this.GetDayCount(
    this.now_day.getFullYear() +
      '-' +
      ('0' + this.now_day.getMonth()).slice(-2) +
      '-' +
      ('0' + this.now_day.getDate()).slice(-2)
  );
  three_months = this.GetDayCount(this.getPrevMonthsDateFromToday(3));
  six_months = this.GetDayCount(this.getPrevMonthsDateFromToday(6));
  year = this.GetDayCount(
    this.now_day.getFullYear() -
      1 +
      '-' +
      ('0' + this.now_day.getMonth()).slice(-2) +
      '-' +
      ('0' + this.now_day.getDate()).slice(-2)
  );
  five_years = this.GetDayCount(
    this.now_day.getFullYear() -
      5 +
      '-' +
      ('0' + this.now_day.getMonth()).slice(-2) +
      '-' +
      ('0' + this.now_day.getDate()).slice(-2)
  );
  max_time = this.GetDayCount('1970-01-01');

  // Variables for modal window
  wShow = true;
  modalIndication;
  modalName;
  modalTime;
  modalDate;
  modalOpen;
  modalClose;
  modalHigh;
  modalLow;
  modalPercent;
  modalDelta;
  modalClass;
  modalChartOptions;
  modalBarOptions;
  chartmodalBar;
  modalChart;
  public preloaderShow = true;
  public mainPreloaderHidden = true;
  // Variables for modal charts
  chartValue;
  modal_chart_points = [];
  modal_chart_info = [];
  modal_series = [];
  // Variables for modal open/close
  modal_info = [];

  public modalShow = true;
  public modalIsNan = false;

  max: any;
  min: any;
  // Types of chart in select
  typeOfData = 'INTRADAY';
  typesOfData: string[] = ['INTRADAY', '1 WEEK', '2 WEEKS', '1 MONTH', '3 MONTHS', '6 MONTHS', '1 YEAR', '5 YEARS', 'MAX'];

  innerHeight: any;
  innerWidth: any;

  chart_value = '1 WEEK';
  onlyIntraday = false;

  isPortrait: boolean;
  timeouts: number[];

  days;

  dataIntraDay = {};
  modal_info_arr;

  table_info_obj = {};
  // performSearch(value): void {
  //   console.log('User entered: ' + value);
  // }

  arrSearch;


  dragItems = [
    { id: 1, name: 'Indices'},
    { id: 2, name: 'Forex'},
    { id: 3, name: 'Commodity'}
  ];

  drop(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.dragItems, event.previousIndex, event.currentIndex);
  }


  @HostListener('window:resize', [])
  onResize() {
    // event.target.innerWidth; // window width
    this.innerWidth = window.screen.width;
    if (window.matchMedia('(orientation: portrait)').matches) {
      this.isPortrait = false;
    } else {
      this.isPortrait = true;
      this.innerWidth = window.screen.width;

      if (this.innerWidth < 500) {
        this.modalChart.setSize(440, 300);
      } else if (this.innerWidth < 600) {
        this.modalChart.setSize(540, 300);
      } else if (this.innerWidth < 800) {
        this.modalChart.setSize(640, 300);
      }
    }
  }

  public clickMe() {}

  constructor(private zone: NgZone) {
    this.table_info = new Array<Object>();
    // Options for table line-charts
    this.options = {
      chart: {
        backgroundColor: null,
        borderWidth: 0,
        type: 'line',
        margin: [2, 0, 2, 0],
        width: 120,
        height: 20,
        style: {
          overflow: 'visible',
        },
        // small optimization, saves 1-2 ms each sparkline
        skipClone: true,
      },
      states: { hover: { enabled: false } },
      colors: ['#28c068'],
      navigator: {
        enabled: false,
      },

      title: {
        text: null,
      },
      credits: {
        enabled: false,
      },
      xAxis: {
        labels: {
          enabled: false,
        },
        title: {
          text: null,
        },
        startOnTick: false,
        endOnTick: false,
        tickPositions: [0],
      },
      yAxis: {
        endOnTick: false,
        startOnTick: false,
        labels: {
          enabled: false,
        },
        title: {
          text: null,
        },
        tickPositions: [0],
      },
      legend: {
        enabled: false,
      },
      tooltip: {
        enabled: false,
      },
      plotOptions: {
        series: {
          lineWidth: 1,
          shadow: false,
          states: {
            hover: {
              lineWidth: 1,
            },
          },
          marker: {
            radius: 1,
            states: {
              hover: {
                radius: 2,
              },
            },
          },
          fillOpacity: 0,
        },
        column: {
          negativeColor: '#fff',
          borderColor: '#fff',
        },
        line: {
          marker: {
            enabled: false,
          },
        },
      },
      series: [
        {
          data: [],
          zones: [
            {
              value: 0,
              color: '#ed1c24',
            },
            {
              value: 0,
              color: '#ed1c24',
            },
            {
              color: '#25bf64',
            },
          ],
          pointInterval: 900000,
        },
      ],
    };

    // Options for modal line-chart
    this.modalChartOptions = {
      chart: {
        zoomType: 'x',
        type: 'area',
        // height: 300,
        // width: 1080,
      },
      loading: {
        style: {
          backgroundColor: 'silver',
        },
        labelStyle: {
          color: 'white',
        },
      },
      title: {
        text: '',
      },
      states: { hover: { enabled: false } },
      colors: [
        {
          linearGradient: { x1: 0, y1: 0, x2: 1, y2: 1 },
          stops: [[0, 'rgb(255, 255, 255)'], [1, 'rgb(200, 200, 255)']],
        },
      ],
      subtitle: {
        text: '',
      },
      xAxis: {
        title: {
          text: '',
        },
      },
      yAxis: {
        title: {
          text: '',
        },
        labels: {
          align: 'right',
          x: 5,
        },
      },
      series: [
        {
          name: '',
          type: 'area',
          pointInterval: 900000,
          data: [],
          zones: [
            {
              value: 0,
              color: 'rgba(237, 28, 36, 1)',
            },
            {
              value: this.chartValue,
              color: 'rgba(37, 191, 100, 1)',
            },
            {
              color: 'rgba(237, 28, 36, 1)',
            },
          ],
        },
      ],
      rangeSelector: {
        buttonTheme: {
          visibility: 'hidden',
        },
        labelStyle: {
          visibility: 'hidden',
        },
        inputEnabled: false,
      },
      exporting: {
        enabled: true,
      },
      navigator: {
        enabled: false,
      },
      legend: {
        enabled: false,
      },
      tooltip: {
        split: 'true',
        pointFormat: 'Value: {point.y:.2f}',
      },
      plotOptions: {
        series: {
          compare: 'percent',
          showInNavigator: false,
          pointWidth: 60,
          fillOpacity: 0.2,
        },
        area: {
          marker: {
            enabled: false,
          },
        },
      },
    };

    // Options for table bar-charts
    this.options3 = {
      chart: {
        type: 'bar',
        height: 20,
        width: 120,
        spacingBottom: 0,
        spacingTop: 0,
        spacingLeft: 0,
        spacingRight: 0,
      },
      title: {
        text: '',
      },
      subtitle: {
        text: '',
      },
      colors: ['#28c068'],
      xAxis: {
        labels: {
          enabled: false,
        },
        title: {
          text: null,
        },
        startOnTick: false,
        endOnTick: false,
        tickPositions: [0],
      },
      yAxis: {
        endOnTick: false,
        startOnTick: false,
        labels: {
          enabled: false,
        },
        title: {
          text: null,
        },
        tickPositions: [0],
      },
      legend: {
        enabled: false,
      },
      tooltip: {
        enabled: false,
      },

      plotOptions: {
        series: {
          stacking: 'normal',
        },
        bar: {
          zones: [
            {
              value: 0, // Values up to 10 (not including) ...
              color: 'rgba(237, 29, 35, 0.6)', // ... have the color blue.
            },
            {
              color: 'rgba(39, 190, 102, 0.61)', // Values from 10 (including) and up have the color red
            },
          ],
        },
      },

      series: [
        {
          data: [0],
        },
        {
          data: [0],
        },
      ],
    };

    // Options for modal bar-chart
    this.modalBarOptions = {
      chart: {
        type: 'bar',
        height: 20,
        spacingBottom: 0,
        spacingTop: 0,
        spacingLeft: 0,
        spacingRight: 0,
      },
      states: { hover: { enabled: false } },
      title: {
        text: '',
      },
      subtitle: {
        text: '',
      },
      credits: {
        enabled: false,
      },
      xAxis: {
        labels: {
          enabled: false,
        },
        title: {
          text: null,
        },
        startOnTick: false,
        endOnTick: false,
        tickPositions: [0],
      },
      yAxis: {
        endOnTick: false,
        startOnTick: false,
        labels: {
          enabled: false,
        },
        title: {
          text: null,
        },
        tickPositions: [0],
      },
      legend: {
        enabled: false,
      },
      tooltip: {
        enabled: false,
      },

      plotOptions: {
        series: {
          stacking: 'normal',
        },
      },

      series: [
        {
          name: 'High',
          data: [[], []],
          color: 'rgb(39, 190, 102)',
        },
        {
          name: 'Open',
          data: [],
          color: 'rgb(237, 29, 35)',
        },
        // },{
        //   name: 'indicator',
        //   data: [],
        //   color: 'black',
        //   type: 'scatter',
        //   marker:{
        //     //here you can have your url
        //     symbol: 'https://www.researchgate.net/
        // profile/Kyriaki_Mikellidou/publication/264201750/figure/
        // download/fig2/AS:288776888434689@1445861183969/
        // Figure-2-The-vertical-horizontal-illusion-Although-of-equal-lengths-the-vertical-line.png',
        //   }
      ],
    };
  }

  sort(property) {
    this.isDesc = !this.isDesc; // change the direction
    this.column = property;
    this.direction = this.isDesc ? 1 : -1;
  }

  GetDayCount(day) {
    const cell_date = new Date(day); // months 0-11, days 1-31
    const diffTime = Math.abs(this.now_day.getTime() - cell_date.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 3600 * 24)); // in higher
    return diffDays;
  }

  // Instance for charts
  saveInstance(chartInstance): void {
    this.chartList[chartInstance.renderTo.id] = chartInstance;
    this.chart = chartInstance;
  }

  saveInstanceBar(chartInstance): void {
    this.chartListBar[chartInstance.renderTo.id] = chartInstance;
    this.chartBar = chartInstance;
  }

  saveInstancemodalBar(chartInstance): void {
    this.chartmodalBar = chartInstance;
  }

  saveInstancemodal(chartInstance): void {
    this.modalChart = chartInstance;
  }

  // search table
  search(query: string) {
    this.table_info = this.table_info.filter((i) => i['name'].toLowerCase().indexOf(query.toLowerCase()) > -1);
  }

  // Show modal-window
  show(info) {
    if (window.matchMedia('(orientation: portrait)').matches) {
      this.isPortrait = false;
    } else {
      this.isPortrait = true;
    }

    this.modalIndication = info.indication;
    this.modalTime = info.time;
    this.modalDelta = info.delta;
    this.modalPercent = info.percent;
    this.modalName = info.name;
    this.modalDate = info.time.split(' ')[0];
    this.modalShow = false;
    this.modalOpen = info.openValue;
    this.modalClose = info.closeValue;
    this.modalHigh = info.highValue;
    this.modalLow = info.lowValue;
    this.modalClass = info.classValue;
    this.preloaderShow = false;
    this.modalIsNan = isNaN(this.modalDelta);

    if (this.fx_indexes.includes(this.modalName) || this.com_indexes.includes(this.modalName)) {
      this.onlyIntraday = true;
    } else {
      this.onlyIntraday = false;
    }

    this.chartmodalBar.series[0].setData([+this.modalHigh]);
    this.chartmodalBar.series[1].setData([+this.modalOpen]);
    // this.chartmodalBar.series[2].setData([+this.modalIndication]);
    this.chartmodalBar.yAxis[0].setExtremes(+this.modalLow, +this.modalHigh);

    this.getIntradayChart(this.modalName);

    this.modalChart.series[0].update({ name: this.modalName });

    if (this.fx_indexes.includes(this.modalName)) {
      this.modalChart.series[0].update({ tooltip: { pointFormat: 'Value: {point.y:.4f}' } });
    } else {
      this.modalChart.series[0].update({ tooltip: { pointFormat: 'Value: {point.y:.2f}' } });
    }

    this.typeOfData = this.typesOfData[0] || null;

    // this.modalChart.yAxis[0].setExtremes(+this.modalLow, +this.modalHigh);

    // this.modalChart.series[0].zones[1].value = +this.modalClose;

    // this.modalChart.series[0].applyZones();
  }

  callType(value) {
    this.chart_value = value;
    if (this.chart_value === 'INTRADAY') {
      this.modalChart.showLoading();
      this.getIntradayChart(this.modalName);
    } else {
      this.modalChart.showLoading();
      this.getHistoricalChart(this.modalName, this.chart_value);
    }
  }

  getHistoricalChart(name, value) {
    // console.log(this.three_months);
    // console.log(this.six_months);
    // console.log(this.three_months_ago);
    // console.log(this.six_months_ago);
    let done = false;
    const websocket = new WebSocket(this.wsUri);
    this.indexes.forEach((item) => {
      if (item.name === name) {
        websocket.onopen = () => {
          websocket.send('option udl_ccy 0\n');

          if (value === '1 WEEK') {
            websocket.send('historical ' + item.id + ' ' + this.week_ago + ' ' + this.today + '\n');
            this.days = 5;
          } else if (value === '2 WEEKS') {
            websocket.send('historical ' + item.id + ' ' + this.two_weeks_ago + ' ' + this.today + '\n');
            this.days = 14;
          } else if (value === '1 MONTH') {
            websocket.send('historical ' + item.id + ' ' + this.month_ago + ' ' + this.today + '\n');
            this.days = this.month;
          } else if (value === '3 MONTHS') {
            websocket.send('historical ' + item.id + ' ' + this.three_months_ago + ' ' + this.today + '\n');
            this.days = this.three_months;
          } else if (value === '6 MONTHS') {
            websocket.send('historical ' + item.id + ' ' + this.six_months_ago + ' ' + this.today + '\n');
            this.days = this.six_months;
          } else if (value === '1 YEAR') {
            websocket.send('historical ' + item.id + ' ' + this.year_ago + ' ' + this.today + '\n');
            this.days = this.year;
          } else if (value === '5 YEARS') {
            websocket.send('historical ' + item.id + ' ' + this.five_years_ago + ' ' + this.today + '\n');
            this.days = this.five_years;
          } else if (value === 'MAX') {
            websocket.send('historical ' + item.id + ' ' + this.max_time_ago + ' ' + this.today + '\n');
            this.days = this.max_time;
          }
        };
        websocket.onmessage = (evt) => {
          // var response = this.parseResponse(evt.data);
          // console.log(evt.data);
          const str = evt.data.trim(evt.data);

          if (str.match(/done/)) {
            done = true;
            this.redrawHistoricalChart(done);
            return;
          }

          let match = /^([a-z0-9\-]+)@(.*)$/i.exec(str);

          // console.log(match);
          const modal_chart_info_obj = {
            id: match[1],
            dataLine: match[2],
            open: 0,
            close: 0,
            time: '',
          };

          const regex = /([a-z]+):([^:;]+)(?:;|$)/gi;
          let time;
          let open;
          let close;

          while ((match = regex.exec(modal_chart_info_obj.dataLine))) {
            const matchKey = match[1];
            const matchValue = match[2];

            if (matchKey === 'o') {
              // matchKey = 'price';
              open = parseFloat(matchValue);
            } else if (matchKey === 'c') {
              // matchKey = 'time';
              close = parseFloat(matchValue);
            } else if (matchKey === 'd') {
              // matchKey = 'time';
              time = this.parseDate(matchValue);
            }

            // modal_chart_info_obj.open = open;
            modal_chart_info_obj.close = +close;
            modal_chart_info_obj.time = time;
          }

          this.modal_chart_info.push(modal_chart_info_obj);

          // console.log(this.modal_chart_info);
        };
      }
    });
  }

  getIntradayChart(name) {
    let done = false;

    const websocket = new WebSocket(this.wsUri);
    this.indexes.forEach((item) => {
      if (item.name === name) {
        websocket.onopen = () => {
          websocket.send('option udl_ccy 0\n');
          if (
            item.id === 'EUR-USD' ||
            item.id === 'EUR-GBP' ||
            item.id === 'EUR-JPY' ||
            item.id === 'EUR-CHF' ||
            item.id === 'EUR-BTC' ||
            item.id === 'XAU-USD' ||
            item.id === 'XAG-USD'
          ) {
            console.log('outside check');
            websocket.send('intraday_fx ' + item.id + ' ' + this.day_begin + ' ' + this.day_end + '\n');
          } else {
            console.log('inside');
            websocket.send('intraday ' + item.id + ' ' + this.day_begin + ' ' + this.day_end + '\n');
          }
        };
        websocket.onmessage = (evt) => {
          console.log(evt);
          const str = evt.data.trim(evt.data);

          if (str.match(/done/)) {
            done = true;
            this.redrawChart(done);
            return;
          }

          let match = /^([a-z0-9\-]+)@(.*)$/i.exec(str);

          const modal_chart_info_obj = {
            id: match[1],
            dataLine: match[2],
            indication: 0,
            time: '',
          };

          const regex = /([a-z]+):([^:;]+)(?:;|$)/gi;
          let time;
          let bid;
          let ask;

          while ((match = regex.exec(modal_chart_info_obj.dataLine))) {
            const key = match[1];
            const value = match[2];

            if (key === 'p') {
              // key = 'price';
              bid = parseFloat(value);
              ask = parseFloat(value);
            } else if (key === 't') {
              // key = 'time';
              time = this.parseDateIntraday(value);
            }

            modal_chart_info_obj.indication = +((bid + ask) * 0.5);
            modal_chart_info_obj.time = time;
          }

          this.modal_chart_info.push(modal_chart_info_obj);
        };
      }
    });
  }

  redrawHistoricalChart(done) {
    if (done) {
      const arrSearch = [];

      this.modal_chart_info.forEach((message) => {
        let priceValue;
        let timeValue;

        try {
          priceValue = message.close.toFixed(2);
          timeValue = message.time;

          this.modal_chart_points.push([timeValue, +priceValue]);
          arrSearch.push([+priceValue]);

          // console.log(priceValue);
        } catch (err) {
          priceValue = 'start';
          timeValue = 'null';
        }
      });
      if (this.modalChart) {
        this.modalChart.series[0].setData(this.modal_chart_points);
        // console.log(this.modalChart.series[0]);
        // console.log(this.modal_chart_points);
      }

      let min = this.arrSearch[0];
      let max = min;
      // Search for the min and max value
      for (let i = 1; i < arrSearch.length; ++i) {
        if (arrSearch[i - 1] > max) {
          max = arrSearch[i];
        }
        if (arrSearch[i] < min) {
          min = arrSearch[i];
        }
      }

      this.modalHigh = max;
      this.modalLow = min;
      this.chartmodalBar.series[0].setData([+this.modalHigh]);
      this.chartmodalBar.series[1].setData([+this.modalOpen]);
      this.chartmodalBar.yAxis[0].setExtremes(+this.modalLow, +this.modalHigh);
    }
    this.modal_chart_info = [];
    this.modal_chart_points = [];
    this.modalChart.hideLoading();
  }

  redrawChart(done) {
    if (done) {
      const arrSearch = [];
      this.modal_chart_info.forEach((message) => {
        let priceValue;
        let timeValue;

        // ==== Checking that this item belongs to fx
        if (this.fx_indexes.includes(this.modalName)) {
          try {
            priceValue = message.indication.toFixed(4);
            timeValue = message.time;

            this.modal_chart_points.push([timeValue, +priceValue]);
            arrSearch.push(+priceValue);
          } catch (err) {
            priceValue = 'start';
            timeValue = 'null';
          }
        } else {
          try {
            priceValue = message.indication.toFixed(2);
            timeValue = message.time;

            this.modal_chart_points.push([timeValue, +priceValue]);
            arrSearch.push(+priceValue);
          } catch (err) {
            priceValue = 'start';
            timeValue = 'null';
          }
        }
      });
      if (this.modalChart) {
        this.modalChart.series[0].setData(this.modal_chart_points);
      }

      let min = arrSearch[0];
      let max = min;
      // Search for the min and max value
      for (let i = 1; i < arrSearch.length; ++i) {
        if (arrSearch[i - 1] > max) {
          max = arrSearch[i];
        }
        if (arrSearch[i] < min) {
          min = arrSearch[i];
        }
      }

      this.modalHigh = max;
      this.modalLow = min;
      this.chartmodalBar.series[0].setData([+this.modalHigh]);
      this.chartmodalBar.series[1].setData([+this.modalOpen]);
      this.chartmodalBar.yAxis[0].setExtremes(+this.modalLow, +this.modalHigh);
      this.modalOpen = arrSearch[0];
    }
    this.modal_chart_info = [];
    this.modal_chart_points = [];
    this.preloaderShow = true;
    this.modalChart.hideLoading();
  }

  parseDateIntraday(dateStr) {
    const mask = /^(\d\d\d\d)(\d\d)(\d\d)(\d\d)(\d\d)(\d\d)$/.exec(dateStr);
    const timeMask = /^(\d\d)(\d\d)(\d\d)$/.exec(dateStr);
    if (mask) {
      const month = +mask[2] - 1;
      return Date.UTC(+mask[1], month, +mask[3], +mask[4], +mask[5], +mask[6]);
    } else if (timeMask) {
      return Date.UTC(
        this.now_day.getFullYear(),
        this.now_day.getMonth(),
        this.now_day.getDate(),
        +timeMask[1],
        +timeMask[2],
        +timeMask[3]
      );
    }
    return null;
  }

  parseDate(dateStr) {
    const mask = /^(\d\d\d\d)(\d\d)(\d\d)$/.exec(dateStr);
    const month = +mask[2] - 1;
    return Date.UTC(+mask[1], month, +mask[3]);
  }

  hide() {
    this.modalShow = true;
  }

  ngOnInit() {
    initSocket();

    // An array of matches id - name
    const chart_info_obj = {};
    let counter = 0;

    // Set new currency close value
    onSendMessageCurr((messages) => {
      if (!messages) {
        return;
      }

      for (const messID in messages) {
        if (!messages.hasOwnProperty(messID)) {
          continue;
        }

        const messArr = messages[messID];

        const temp_series = [];
        const temp_data_series = [];

        messArr.forEach((message) => {
          let priceValue;
          let timeValue;

          try {
            priceValue = message.data['price'];
            timeValue = message.data['time'];

            temp_series.push(+priceValue);
            temp_data_series.push([timeValue, +priceValue]);
          } catch (err) {
            priceValue = 'start';
            timeValue = 'null';
          }
        });

        // Pass through the indexes array to find the id match
        this.indexes.some((item) => {
          if (item.id === messID) {
            const tableItem = this.table_info_obj[item.id];
            if (tableItem) {
              if (this.fx_indexes.includes(tableItem.name)) {
                tableItem.closeValue = temp_series[temp_series.length - 1].toFixed(4);
              } else if (this.com_indexes.includes(tableItem.name)) {
                tableItem.closeValue = temp_series[temp_series.length - 1].toFixed(2);
              }
            }

            this.modal_series.push({ name: item.name, data: temp_data_series });
            return true;
          }

          return false;
        });
      }
    });

    // Function for line-charts output
    onSendMessageIntraday((messages) => {
      if (!messages) {
        return;
      }

      for (const messID in messages) {
        if (!messages.hasOwnProperty(messID)) {
          continue;
        }

        const messArr = messages[messID];
        const temp_series = [];
        const temp_data_series = [];

        messArr.forEach((message) => {
          let priceValue;
          let timeValue;
          const id = message.id;

          try {
            priceValue = message.data['price'].toFixed(2);
            timeValue = message.data['time'];

            temp_series.push(+priceValue);
            temp_data_series.push([timeValue, +priceValue]);
          } catch (err) {
            priceValue = 'start';
            timeValue = 'null';
          }
        });

        // Pass through the indexes array to find the id match
        this.indexes.some((item) => {
          if (item.id === messID) {
            const tableItem = this.table_info_obj[item.id];
            if (tableItem) {
              if (tableItem) {
                if (this.fx_indexes.includes(tableItem.name)) {
                  tableItem.closeValue = temp_series[0].toFixed(4);
                } else if (this.com_indexes.includes(tableItem.name)) {
                  tableItem.closeValue = temp_series[0].toFixed(2);
                }
              }
            }

            // Add data to chart and draw them
            // this.modal_series.push({name: item.name, data: temp_data_series});
            // if (this.chartList['chart' + item.name]) {
            //   this.chartList['chart' + item.name].series[0].setData(temp_series);
            //   this.chartList['chart' + item.name].series[0].zones[1].value = temp_series[0];
            //   this.chartList['chart' + item.name].series[0].applyZones();
            // }
            return true;
          }

          return false;
        });
      }
    });

    // Function for real-time data output
    onSendMessage((message) => {
      // console.log(message);
      if (message == null) {
        return;
      }

      if (message.error) {
        return;
      }

      let index;
      let time;
      const id = message.id;
      let openValue;
      let closeValue;
      let highValue;
      let lowValue;
      let dateValue;

      try {
        index = message.data['price'];
        time = message.data['time'];
        openValue = message.data['openValue'];
        closeValue = message.data['closeValue'];
        highValue = message.data['highValue'];
        lowValue = message.data['lowValue'];
        dateValue = message.data['dateValue'];
      } catch (err) {
        index = 'start';
        time = 'null';
        openValue = 'start';
        closeValue = 'start';
        highValue = 'start';
        lowValue = 'start';
        dateValue = 'start';
      }

      // Pass through the indexes array to find the id match
      this.indexes.forEach((item) => {
        if (item.id === id) {
          if (item.name === this.modalName) {
            // ==== Checking that this item belongs to fx
            if (this.fx_indexes.includes(item.name)) {
              this.modalIndication = index.toFixed(4); // add FX delta value
            } else {
              this.modalIndication = index.toFixed(2); // add FX delta value
            }
            this.modalTime = time.split(' ')[1];
          }

          const tableItem = this.table_info_obj[item.id];
          // if this item already exists in the object, update
          if (tableItem) {
            if (+tableItem.indication < index) {
              tableItem.newClassValue = 'rise-ind'; // add increment class
            } else if (+tableItem.indication > index) {
              tableItem.newClassValue = 'fall-ind';
            }

            // =============== Increment check ================
            if (tableItem.closeValue < index) {
              tableItem.classValue = 'inc'; // add increment class
              tableItem.percent = '+' + ((index / +tableItem.closeValue - 1) * 100).toFixed(2); // add percent value

              // ==== Checking that this item belongs to fx
              if (this.fx_indexes.includes(item.name)) {
                tableItem.delta = '+' + (index - +tableItem.closeValue).toFixed(4); // add FX delta value
              } else {
                tableItem.delta = '+' + (index - +tableItem.closeValue).toFixed(2); // add other delta value
              }

              if (item.name === this.modalName) {
                // === Checking that this item belongs to fx
                if (this.fx_indexes.includes(item.name)) {
                  this.modalDelta = '+' + (index - +tableItem.closeValue).toFixed(4); // add FX delta value MODAL
                } else {
                  this.modalDelta = '+' + (index - +tableItem.closeValue).toFixed(2); // add other delta value MODAL
                }

                this.modalPercent = '+' + ((index / +tableItem.closeValue - 1) * 100).toFixed(2); // add percent value MODAL
                this.modalClass = 'inc'; // add increment class MODAL
              }

              if (isNaN(tableItem.percent)) {
                tableItem.percent = 0;
              }

              if (openValue === undefined) {
                tableItem.name = item.name;
                tableItem.time = time.split(' ')[1];

                // ==== Checking that this item belongs to fx
                if (this.fx_indexes.includes(item.name)) {
                  tableItem.indication = +index.toFixed(4);
                } else {
                  tableItem.indication = +index.toFixed(2);
                }
              } else if (time === undefined) {
                tableItem.dateValue = dateValue;

                // === Checking that this item belongs to fx
                if (this.fx_indexes.includes(item.name)) {
                  tableItem.highValue = parseFloat(highValue).toFixed(4);
                  tableItem.lowValue = parseFloat(lowValue).toFixed(4);
                  tableItem.openValue = parseFloat(openValue).toFixed(4);
                  tableItem.closeValue = parseFloat(closeValue).toFixed(4);
                } else {
                  tableItem.highValue = parseFloat(highValue).toFixed(2);
                  tableItem.lowValue = parseFloat(lowValue).toFixed(2);
                  tableItem.openValue = parseFloat(openValue).toFixed(2);
                  tableItem.closeValue = parseFloat(closeValue).toFixed(2);
                }
              } else {
                tableItem.name = item.name;
                tableItem.time = time.split(' ')[1];
                // ==== Checking that this item belongs to fx
                if (this.fx_indexes.includes(item.name)) {
                  tableItem.indication = +index.toFixed(4);
                } else {
                  tableItem.indication = +index.toFixed(2);
                }
                tableItem.dateValue = dateValue;

                if (this.fx_indexes.includes(item.name)) {
                  tableItem.highValue = parseFloat(highValue).toFixed(4);
                  tableItem.lowValue = parseFloat(lowValue).toFixed(4);
                  tableItem.openValue = parseFloat(openValue).toFixed(4);
                  tableItem.closeValue = parseFloat(closeValue).toFixed(4);
                } else {
                  tableItem.highValue = parseFloat(highValue).toFixed(2);
                  tableItem.lowValue = parseFloat(lowValue).toFixed(2);
                  tableItem.openValue = parseFloat(openValue).toFixed(2);
                  tableItem.closeValue = parseFloat(closeValue).toFixed(2);
                }

                tableItem.mainIndex = index;
              }

              // ============= Decrement check ===========
            } else {
              tableItem.percent = ((index / +tableItem.closeValue - 1) * 100).toFixed(2); // add percent value
              tableItem.classValue = 'dec'; // add decrement class
              // ==== Checking that this item belongs to fx
              if (this.fx_indexes.includes(item.name)) {
                tableItem.delta = (index - +tableItem.closeValue).toFixed(4); // add delta value
              } else {
                tableItem.delta = (index - +tableItem.closeValue).toFixed(2); // add delta value
              }
              if (item.name === this.modalName) {
                if (!!tableItem.closeValue) {
                  this.modalPercent = ((index / +tableItem.closeValue - 1) * 100).toFixed(2); // add percent value MODAL
                }
                this.modalClass = 'inc'; // add decrement class MODAL
                // ==== Checking that this item belongs to fx
                if (this.fx_indexes.includes(item.name)) {
                  this.modalDelta = (index - +tableItem.closeValue).toFixed(4); // add delta value MODAL
                } else {
                  this.modalDelta = (index - +tableItem.closeValue).toFixed(2); // add delta value MODAL
                }
              }

              if (isNaN(tableItem.percent)) {
                tableItem.percent = 0;
              }
              if (openValue === undefined) {
                tableItem.name = item.name;
                tableItem.time = time.split(' ')[1];
                // ==== Checking that this item belongs to fx
                if (this.fx_indexes.includes(item.name)) {
                  tableItem.indication = +index.toFixed(4);
                } else {
                  tableItem.indication = +index.toFixed(2);
                }
              } else if (time === undefined) {
                tableItem.dateValue = dateValue;
                // ==== Checking that this item belongs to fx
                if (this.fx_indexes.includes(item.name)) {
                  tableItem.highValue = parseFloat(highValue).toFixed(4);
                  tableItem.lowValue = parseFloat(lowValue).toFixed(4);
                  tableItem.openValue = parseFloat(openValue).toFixed(4);
                  tableItem.closeValue = parseFloat(closeValue).toFixed(4);
                } else {
                  tableItem.highValue = parseFloat(highValue).toFixed(2);
                  tableItem.lowValue = parseFloat(lowValue).toFixed(2);
                  tableItem.openValue = parseFloat(openValue).toFixed(2);
                  tableItem.closeValue = parseFloat(closeValue).toFixed(2);
                }
                tableItem.mainIndex = +index;
              } else {
                tableItem.name = item.name;
                tableItem.time = time.split(' ')[1];
                tableItem.dateValue = dateValue;
                tableItem.mainIndex = +index;

                // ==== Checking that this item belongs to fx
                if (this.fx_indexes.includes(item.name)) {
                  tableItem.indication = +index.toFixed(4);
                  tableItem.highValue = parseFloat(highValue).toFixed(4);
                  tableItem.lowValue = parseFloat(lowValue).toFixed(4);
                  tableItem.openValue = parseFloat(openValue).toFixed(4);
                  tableItem.closeValue = parseFloat(closeValue).toFixed(4);
                } else {
                  tableItem.indication = +index.toFixed(2);
                  tableItem.highValue = parseFloat(highValue).toFixed(2);
                  tableItem.lowValue = parseFloat(lowValue).toFixed(2);
                  tableItem.openValue = parseFloat(openValue).toFixed(2);
                  tableItem.closeValue = parseFloat(closeValue).toFixed(2);
                }
              }
            }
            // If this item is not in the object, create new
          } else {
            if (openValue === undefined) {
              // ==== Checking that this item belongs to fx
              if (this.fx_indexes.includes(item.name)) {
                this.table_info_obj[item.id] = {
                  id: item.id,
                  name: item.name,
                  time: time.split(' ')[1],
                  indication: +index.toFixed(4),
                  chartOptions: JSON.parse(JSON.stringify(this.options)),
                  chartBarOptions: JSON.parse(JSON.stringify(this.options3)),
                  classValue: '',
                  newClassValue: '',
                  percent: 0,
                  delta: 0,
                  firstIndex: index.toFixed(4),
                };
              } else {
                this.table_info_obj[item.id] = {
                  id: item.id,
                  name: item.name,
                  time: time.split(' ')[1],
                  indication: +index.toFixed(2),
                  chartOptions: JSON.parse(JSON.stringify(this.options)),
                  chartBarOptions: JSON.parse(JSON.stringify(this.options3)),
                  classValue: '',
                  newClassValue: '',
                  percent: 0,
                  delta: 0,
                  firstIndex: index.toFixed(2),
                };
              }
            } else {
              // ==== Checking that this item belongs to fx
              if (this.fx_indexes.includes(item.name)) {
                this.table_info_obj[item.id] = {
                  openValue: openValue.toFixed(4),
                  closeValue: closeValue.toFixed(4),
                  highValue: highValue.toFixed(4),
                  lowValue: lowValue.toFixed(4),
                  dateValue: dateValue,
                  chartOptions: JSON.parse(JSON.stringify(this.options)),
                  chartBarOptions: JSON.parse(JSON.stringify(this.options3)),
                };
              } else {
                this.table_info_obj[item.id] = {
                  openValue: openValue.toFixed(2),
                  closeValue: closeValue.toFixed(2),
                  highValue: highValue.toFixed(2),
                  lowValue: lowValue.toFixed(2),
                  dateValue: dateValue,
                  chartOptions: JSON.parse(JSON.stringify(this.options)),
                  chartBarOptions: JSON.parse(JSON.stringify(this.options3)),
                };
              }
            }
          }

          // Outputting table bar-charts
          const itemChartBar = this.chartListBar['chartBar' + item.name];
          if (itemChartBar) {
            itemChartBar.yAxis[0].setExtremes(-2, 2);
            if (tableItem.percent > 0) {
              itemChartBar.series[1].setData([+this.table_info_obj[item.id].percent]);
              itemChartBar.series[0].setData([0]);
            } else {
              itemChartBar.series[0].setData([+this.table_info_obj[item.id].percent]);
              itemChartBar.series[1].setData([0]);
            }
          }

          if (!isFinite(this.table_info_obj[item.id].percent)) {
            this.table_info_obj[item.id].percent = 0;
          }

          return true;
        }

        return false;
      });

      this.arrSearch = [];

      this.min = this.arrSearch[0];
      this.max = this.min;

      // Data output
      // if (counter >= 10) {

      this.zone.run(() => {
        this.table_info = [];
        this.table_info_fx = [];
        this.table_info_com = [];
        for (const key in this.table_info_obj) {
          if (!this.table_info_obj.hasOwnProperty(key)) {
            continue;
          }

          const tableItem = this.table_info_obj[key];

          if (this.com_indexes.includes(tableItem.name)) {
            this.table_info_com.push(tableItem);
          } else if (this.fx_indexes.includes(tableItem.name)) {
            this.table_info_fx.push(tableItem);
          } else {
            this.table_info.push(tableItem);
            this.arrSearch.push(tableItem.indication);
            const query = document.getElementById('system-search') as HTMLInputElement;
            if (!!query && !!query.value && query.value !== '') {
              this.search(query.value);
            }
          }
        }
        // Search for te min and max value
        for (let i = 1; i < this.arrSearch.length; ++i) {
          if (this.arrSearch[i - 1] > this.max) {
            this.max = this.arrSearch[i];
          }
          if (this.arrSearch[i] < this.min) {
            this.min = this.arrSearch[i];
          }
        }
      });

      //   counter = 0;
      // }

      counter++;
    });
  }
  getPrevMonthsDateFromToday(months) {
    const today = this.now_day;
    let month;
    let date;
    let year;
    let newMonth;
    let newDate;
    let newYear;
    month = today.getMonth();
    year = (month - months) <= 0 ? today.getFullYear() - 1 : today.getFullYear();
    date = today.getDate();
    const backdate = new Date((year + 1), (month - months), date);
    newYear = backdate.getFullYear();
    newMonth = ('0' + (backdate.getMonth() + 1)).slice(-2);
    newDate = ('0' + backdate.getDate()).slice(-2);
    return `${newYear}-${newMonth}-${newDate}`;
  }
  ngAfterInit() {}
}
