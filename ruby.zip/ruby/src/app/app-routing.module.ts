import { NgModule, ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule, CanActivate } from '@angular/router';
import { SecurityGuard } from '@smt/navigation-ui';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    canActivate: [SecurityGuard],
    path: 'home',
    loadChildren: './home/home.module#HomeModule'
  }
];
const rootRouting: ModuleWithProviders = RouterModule.forRoot(routes, { useHash: true });
@NgModule({
  imports: [rootRouting],
  exports: [RouterModule]
})
export class AppRoutingModule { }
