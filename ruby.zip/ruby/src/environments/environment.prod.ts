export const environment = {
  production: true,
  api_entry: ''
};
